/** Automatically generated file. DO NOT MODIFY */
package net.binarysailor.shopping;

public final class BuildConfig {
	public final static boolean DEBUG = true;
}